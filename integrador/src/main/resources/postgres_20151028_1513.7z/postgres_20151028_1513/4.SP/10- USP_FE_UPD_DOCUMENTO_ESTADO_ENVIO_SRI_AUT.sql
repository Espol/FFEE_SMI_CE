﻿
-- ok

CREATE OR REPLACE FUNCTION USP_FE_UPD_DOCUMENTO_ESTADO_ENVIO_SRI_AUT(
  pId_periodo         DOCUMENTO.id_periodo%TYPE,
  pId_sociedad        DOCUMENTO.id_sociedad%TYPE,
  pSecuencia          DOCUMENTO.secuencia%TYPE,
  pAck_autorizacion   DOCUMENTO.ack_sri%TYPE,
  pEstado_sri         DOCUMENTO.estado_sri%TYPE,
  pPdf         	      DOCUMENTO.pdf%TYPE,
  pEscenario          DOCUMENTO.escenario%TYPE,
  pEnvio_Mail         DOCUMENTO.envio_mail%TYPE,
  pNroAutorizacion    DOCUMENTO.nro_autorizacion%TYPE,
  pFechaAutorizacion  DOCUMENTO.fecha_autorizacion%TYPE,
  pMensaje            DOCUMENTO.mensaje%TYPE
)
RETURNS INTEGER AS $$
BEGIN
 
    -- ACTUALIZA LA SEGUNDA RESPUESTA DE SRI
    UPDATE DOCUMENTO SET 
        ack_sri     = pAck_autorizacion,
        estado_sri  = pEstado_sri,
        pdf		= pPdf,
        estado		= 'TE',
  escenario  = pEscenario,
  envio_mail = pEnvio_mail,
  nro_autorizacion = pNroAutorizacion,
  fecha_autorizacion = pFechaAutorizacion,
  mensaje    = pMensaje
    WHERE id_periodo    = pId_periodo 
        AND id_sociedad = pId_sociedad 
        AND secuencia   = pSecuencia
        AND ultimo      = TRUE;

  -- FINALIZA EL SEGUNDO ENVIO: DESTINO: 'ST'
  UPDATE ENVIO_DOCUMENTO SET 
       estado = 'TE'
  WHERE id_periodo    = pId_periodo
      AND id_sociedad = pId_sociedad
      AND secuencia   = pSecuencia
      AND destino     = 'ST';

	-- INSERTA EL ENVIO A SAP: DESTINO: 'SA'
        INSERT INTO ENVIO_DOCUMENTO(ID_ENVIO, ID_PERIODO, ID_SOCIEDAD, SECUENCIA, DESTINO, ESTADO)
        VALUES ( NEXTVAL('SQ_FE_ENVIO_DOCUMENTO'), pId_periodo, pId_sociedad, pSecuencia, 'SA', 'PE');

	-- AUTORIZADO O RECHAZADO
      INSERT INTO ENVIO_DOCUMENTO(ID_ENVIO, ID_PERIODO, ID_SOCIEDAD, SECUENCIA, DESTINO, ESTADO) 
      VALUES ( NEXTVAL('SQ_FE_ENVIO_DOCUMENTO'), pId_periodo, pId_sociedad, pSecuencia, 'MO', 'PE');

  RETURN 1;
END;
$$ LANGUAGE plpgsql;